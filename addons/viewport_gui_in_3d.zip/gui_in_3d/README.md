# GUI in 3D

A demo showing a GUI instanced within a 3D scene using viewports,
as well as forwarding mouse and keyboard input to the GUI.

Language: GDScript

Renderer: Compatibility

Check out this demo on the asset library: https://godotengine.org/asset-library/asset/127

## Screenshots

![Screenshot](screenshots/gui.png)
